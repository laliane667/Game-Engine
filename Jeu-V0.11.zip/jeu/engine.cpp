#include "engine.h"

Engine *Engine::s_Instance = nullptr;


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}
// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

GLfloat vertices[] =
{ //     COORDINATES     /        COLORS          /    TexCoord   /        NORMALS       //
	-1.0f, 0.0f, -1.0f,      0.0f, 0.0f, 0.0f,      0.0f, 0.0f,       0.0f, 1.0f, 0.0f,
	 1.0f, 0.0f, -1.0f,      0.0f, 0.0f, 0.0f,      0.0f, 1.0f,       0.0f, 1.0f, 0.0f,
	 1.0f, 0.0f,  1.0f,      0.0f, 0.0f, 0.0f,      1.0f, 1.0f,       0.0f, 1.0f, 0.0f,
    -1.0f, 0.0f,  1.0f,      0.0f, 0.0f, 0.0f,      1.0f, 0.0f,       0.0f, 1.0f, 0.0f
};


// Indices for vertices order
GLuint indices[] =
{
    0, 1, 2,
    0, 2, 3
};

GLfloat lightVertices[] =
{ //     COORDINATES     //
	-0.1f, -0.1f,  0.1f,
	-0.1f, -0.1f, -0.1f,
	 0.1f, -0.1f, -0.1f,
	 0.1f, -0.1f,  0.1f,
	-0.1f,  0.1f,  0.1f,
	-0.1f,  0.1f, -0.1f,
	 0.1f,  0.1f, -0.1f,
	 0.1f,  0.1f,  0.1f
};

GLuint lightIndices[] =
{
	0, 1, 2,
	0, 2, 3,
	0, 4, 7,
	0, 7, 3,
	3, 7, 6,
	3, 6, 2,
	2, 6, 5,
	2, 5, 1,
	1, 5, 4,
	1, 4, 0,
	4, 5, 6,
	4, 6, 7
};

bool Engine::initialize()
{
    cout << "Engine init..." << endl;
    set_etape("MENU");
    User u; m_user = u;
    srand(time(NULL));

    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    m_window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, m_gameName.c_str(), NULL, NULL);

    if (m_window == NULL)
    {
        cout << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(m_window);
    glfwSetFramebufferSizeCallback(m_window, framebuffer_size_callback);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        cout << "Failed to initialize GLAD" << endl;
        return false;
    }

    m_shaderProgram = new Shader("resource/Shaders/default.vert", "resource/Shaders/default.frag");
    m_VAO = new VAO();
    m_VAO->Bind();

    m_VBO = new VBO(vertices, sizeof(vertices));
    m_EBO = new EBO(indices, sizeof(indices));

    m_VAO->LinkAttrib(*m_VBO, 0, 3, GL_FLOAT, 11*sizeof(float), (void*)0);
    m_VAO->LinkAttrib(*m_VBO, 1, 3, GL_FLOAT, 11*sizeof(float), (void*)(3* sizeof(float)));
    m_VAO->LinkAttrib(*m_VBO, 2, 2, GL_FLOAT, 11*sizeof(float), (void*)(6* sizeof(float)));
    m_VAO->LinkAttrib(*m_VBO, 3, 3, GL_FLOAT, 11*sizeof(float), (void*)(8* sizeof(float)));

    m_VAO->Unbind();
    m_VBO->Unbind();
    m_EBO->Unbind();


    // Shader for light cube
	m_lightShader = new Shader("resource/Shaders/light.vert", "resource/Shaders/light.frag");
	// Generates Vertex Array Object and binds it
	m_lightVAO = new VAO();
	m_lightVAO->Bind();
	// Generates Vertex Buffer Object and links it to vertices
	m_lightVBO = new VBO(lightVertices, sizeof(lightVertices));
	// Generates Element Buffer Object and links it to indices
	m_lightEBO = new EBO(lightIndices, sizeof(lightIndices));
	// Links VBO attributes such as coordinates and colors to VAO
	m_lightVAO->LinkAttrib(*m_lightVBO, 0, 3, GL_FLOAT, 3 * sizeof(float), (void*)0);
	// Unbind all to prevent accidentally modifying them
	m_lightVAO->Unbind();
	m_lightVBO->Unbind();
	m_lightEBO->Unbind();

	glm::vec4 lightColor = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f);
	glm::vec3 lightPos = glm::vec3(0.5f, 0.5f, 0.5f);
	glm::mat4 lightModel = glm::mat4(1.0f);
	lightModel = glm::translate(lightModel, lightPos);

	glm::vec3 pyramidPos = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::mat4 pyramidModel = glm::mat4(1.0f);
	pyramidModel = glm::translate(pyramidModel, pyramidPos);


	m_lightShader->Activate();
	glUniformMatrix4fv(glGetUniformLocation(m_lightShader->ID, "model"), 1, GL_FALSE, glm::value_ptr(lightModel));
	glUniform4f(glGetUniformLocation(m_lightShader->ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	m_shaderProgram->Activate();
	glUniformMatrix4fv(glGetUniformLocation(m_shaderProgram->ID, "model"), 1, GL_FALSE, glm::value_ptr(pyramidModel));
	glUniform4f(glGetUniformLocation(m_shaderProgram->ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	glUniform3f(glGetUniformLocation(m_shaderProgram->ID, "lightPos"), lightPos.x, lightPos.y, lightPos.z);

    Texture brick("resource/Textures/package/concrete.jpg", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGB, GL_UNSIGNED_BYTE);
    m_textures.push_back(brick);
    m_textures[0].texUnit(*m_shaderProgram, "tex0", 0);

    glEnable(GL_DEPTH_TEST);

    m_camera = new Camera(SCR_WIDTH, SCR_HEIGHT, glm::vec3(0.0f, 0.0f, 2.0f));

    return true;

}


void Engine::run()
{
        processInput(m_window);
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        m_camera->Inputs(m_window);
        m_camera->updateMatrix(45.0f, 0.1f, 100.0f);

        m_shaderProgram->Activate();
        glUniform3f(glGetUniformLocation(m_shaderProgram->ID, "camPos"), m_camera->Position.x, m_camera->Position.y, m_camera->Position.z);
        m_camera->Matrix(*m_shaderProgram, "camMatrix");

        m_textures[0].Bind();
        m_VAO->Bind();

        m_time = (float)glfwGetTime();
        m_deltaTime = m_time - m_lastTime;
        m_framePerSecond = 1/ m_deltaTime;
        m_lastTime = m_time;
        directory();

        glDrawElements(GL_TRIANGLES, sizeof(indices)/sizeof(int), GL_UNSIGNED_INT, 0);

        m_lightShader->Activate();
        m_camera->Matrix(*m_lightShader, "camMatrix");
        m_lightVAO->Bind();
        glDrawElements(GL_TRIANGLES, sizeof(lightIndices) / sizeof(int), GL_UNSIGNED_INT, 0);

        glfwSwapBuffers(m_window);
        glfwPollEvents();

}


void Engine::directory()
{
    if(get_etape() == "MENU")
        GetInstance()->Menu();
    else if(get_etape() == "INITGAME")
        Game::GetInstance()->initialize();
    else if(get_etape() == "INGAME")
        Game::GetInstance()->inGame();
}

void Engine::Menu()
{


}

void Engine::quit()
{
    m_shaderProgram->Delete();  m_lightShader->Delete();
    m_EBO->Delete();            m_lightEBO->Delete();
    m_VAO->Delete();            m_lightVAO->Delete();
    m_VBO->Delete();            m_lightVBO->Delete();

    delete Game::GetInstance();
    delete World::GetInstance();
    delete m_camera;
    delete m_shaderProgram; delete m_lightShader;
    delete m_EBO;           delete m_lightEBO;
    delete m_VAO;           delete m_lightVAO;
    delete m_VBO;           delete m_lightEBO;
    for(unsigned long t = 0; t < m_textures.size(); t++)
        m_textures[t].Delete();

    cout << "Quit success..." << endl;
}

unsigned Engine::ten_exposant_n(unsigned n)
{
    unsigned i, res = 1;

    for(i = 0; i < n; i++)
        res*= 10;

    return res;
}

double Engine::arrondi(const double x, unsigned n)
{
    unsigned N = ten_exposant_n(n);
    return floor(x * N + 0.5)/N;
}
