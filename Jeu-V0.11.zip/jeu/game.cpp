#include "game.h"

Game *Game::s_Instance = nullptr;

void Player::initialize(string name)
{
    Vector2D p(0,5); m_pos = p;
    Vector2D v(0,0); m_vit = v;
    Vector2D a(0,0); m_acc = a;

    m_name = name;
}

void Player::update()
{
    Vector2D R, F;
    R = World::GetInstance()->getCollision(m_pos.getX() + m_vit.getX() * Engine::GetInstance()->getDeltaTime(), m_pos.getY() + m_vit.getY() * Engine::GetInstance()->getDeltaTime());
    if(R.getX()!=0)
        R.setX(R.getX()/abs(R.getX()));
    if(R.getY()!=0)
        R.setY(R.getY()/abs(R.getY()));

    //cout << "X: " << m_pos.getX() << " / Y: " << m_pos.getY() << endl;
    /// CALCUL DE L'ETAT DU JOUEUR
    if(R.getX() == 0 && R.getY() == 0)
        m_onGround = false;
    else if(R.getY() != 0) m_onGround = true;

    /// ON APPLIQUE  LA REACTION NORMALE
    if(m_onGround)
    {
        R.setY(R.getY() *m_mass* Engine::GetInstance()->getGravity());
        F.setValue(m_gripConstant, 0);
    }
    //if(R.getX() != 0 && R.getY() == 0)
    //cout << "R: " << R.getX() << " " << R.getY() << endl;


    /// APPLICATION DE LA 2E LOI DE NEWTON
    m_acc.setX(R.getX()*Engine::GetInstance()->getBounceConst());
    m_acc.setY(((R.getY())/m_mass) - Engine::GetInstance()->getGravity());
    if(m_acc.getY() == 0) m_vit.setY(0);

    cout << "X: " << m_acc.getX() << " / Y: " << m_acc.getY() << endl;


    /// GESTION DU SAUT
    /*if(Engine::GetInstance()->get_keyProtect("SPACE") == true && key[KEY_SPACE] && m_onGround)
    {
        Engine::GetInstance()->set_keyProtect("SPACE", false);
        m_vit.setY( m_vit.getY() + m_jumpForce);
    }

    /// GESTION DES DEPLACEMENTS GAUCHE / DROITE
    if(abs(m_vit.getX()) < m_speedMax)
    {
        if (key[KEY_RIGHT] && !key[KEY_LEFT] && m_vit.getX() >= 0)
            m_acc.setX( m_acc.getX() + m_speedForce/ m_mass);
        if(key[KEY_LEFT] && !key[KEY_RIGHT] && m_vit.getX() <= 0)
            m_acc.setX( m_acc.getX() - m_speedForce/ m_mass);
    }
    if((key[KEY_RIGHT] && !key[KEY_LEFT] && m_vit.getX() < 0) || (key[KEY_LEFT] && !key[KEY_RIGHT]  && m_vit.getX() > 0))
        m_vit.setX( -m_vit.getX());

    if(m_vit.getX() > m_speedMax && m_onGround)  m_vit.setX(m_speedMax);
    else if(m_vit.getX() < -m_speedMax && m_onGround)  m_vit.setX(-m_speedMax);

    /// APPLIQUER LES FORCES DE FROTTEMENTS
    if(m_onGround)
        if(abs(m_vit.getX()) > 0)
            m_vit.setX( m_vit.getX()/ (F.getX()*m_mass) );

    /// MISE A JOUR DES VECTEURS VITESSE ET POSITION
    m_vit.setX( m_vit.getX() + m_acc.getX() * Engine::GetInstance()->getDeltaTime());
    m_vit.setY( m_vit.getY() + m_acc.getY() * Engine::GetInstance()->getDeltaTime());

    m_pos.setX( m_pos.getX() + m_vit.getX() * Engine::GetInstance()->getDeltaTime());
    m_pos.setY( m_pos.getY() + m_vit.getY() * Engine::GetInstance()->getDeltaTime());*/

}

void Player::display()
{
    //circlefill(Engine::GetInstance()->get_bitmap("PAGE"),Engine::GetInstance()->getXCam(m_pos.getX()), Engine::GetInstance()->getYCam(m_pos.getY()),10, makecol(125,0,125));
}

void Game::initialize()
{
    string name = Engine::GetInstance()->getUserName();
    Player p;
    p.initialize(name);
    m_players.push_back(p);
    World::GetInstance()->initialize();
    Engine::GetInstance()->set_etape("INGAME");
}

void Game::inGame()
{
    World::GetInstance()->displayWorld();
    for(int i = 0; i < m_players.size(); i++)
    {
        m_players[i].update();
        m_players[i].display();
    }
}
