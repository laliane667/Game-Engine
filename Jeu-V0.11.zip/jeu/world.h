#ifndef WORLD_H
#define WORLD_H

#include "header.h"
#include "engine.h"

class Floor
{
    public:
        Floor(){}
        ~Floor(){}
        double get_y(){return m_y;}
        double get_x(){return m_x;}

    private:
        double m_x = 0;
        double m_y = 0;
};

class Point
{
    public:
        Point(){}
        Point(double x, double y){m_x = x; m_y = y;}
        ~Point(){}

        double getX(){return m_x;}
        double getY(){return m_y;}

        void setX(double x){m_x = x;}
        void setY(double y){m_y = y;}

        void display();

    private:
        double m_x;
        double m_y;
};

class Object
{
    public:
        Object(){}
        ~Object(){}

        void initialize();
        void display();
        void addPoint(Point p){m_points.push_back(p);}
        Vector2D getCollision(double x, double y);
        void update();

    private:
        vector<Point> m_points;
        vector<Vector2D> m_vectors;
        vector<Vector2D> m_normalVectors;
        vector<bool> m_collisionToSide;
        vector<int> m_distToSide;
};

class World
{
    public:
        static World* GetInstance(){
            return s_Instance = (s_Instance != nullptr)? s_Instance : new World();
        }
        ~World(){}

        void initialize();
        Vector2D getCollision(double x, double y);
        void displayWorld();


    private:
        static World* s_Instance; ///UNIQUE INSTANCE DE LA CLASSE ENGINE, OMNIPRESENTE DU DEBUT A LA FIN DU JEU
        Floor m_floor;
        vector<Object> m_objects;
};

#endif // WORLD_H
