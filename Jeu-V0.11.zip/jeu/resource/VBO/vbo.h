#ifndef VBO_H
#define VBO_H

#include <glad/glad.h>

class VBO
{
    public:
        GLuint ID;
        VBO(GLfloat* vertices, GLsizeiptr Size);

        void Bind();
        void Unbind();
        void Delete();

};

#endif // VBO_H
