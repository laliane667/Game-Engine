#ifndef ENGINE_H
#define ENGINE_H
#include "header.h"
#include "game.h"
#include "shaders.h"
#include "vbo.h"
#include "vao.h"
#include "ebo.h"
#include "texture.h"
#include "camera.h"

class User
{
    private:
        string m_UserName;
    public:
        User(){}
        ~User(){}

        void setUserName(string name){m_UserName = name;}
        string getUserName(){return m_UserName;}
};

///================================================================\\ ENGINE // =====================================================================

class Engine
{
    private:
        static Engine* s_Instance; ///UNIQUE INSTANCE DE LA CLASSE ENGINE, OMNIPRESENTE DU DEBUT A LA FIN DU JEU

        ///GLFW VARIABLES///
        GLFWwindow* m_window;
        Camera* m_camera;
        Shader* m_shaderProgram, *m_lightShader;
        VAO* m_VAO, *m_lightVAO;
        VBO* m_VBO, *m_lightVBO;
        EBO* m_EBO, *m_lightEBO;
        vector<Texture> m_textures;

        ///GAME VARIABLES///
        string m_gameName = "Jeu_v:0.1";
        string m_etapeActuelle; ///AIGUILLAGE QUI PERMET DE SE DEPLACER ENTRE LES DIFFERENTS MENUS
        User m_user;
        double m_framePerSecond = 0;
        bool m_loopDone = false;
        float m_UT = 1, m_time = 0, m_lastTime = 0, m_deltaTime = 0;
        double m_gravity = 12;
        int m_bounceConst = 30;

    public:
        static Engine* GetInstance(){
            return s_Instance = (s_Instance != nullptr)? s_Instance : new Engine();
        }
        ~Engine(){}

        bool initialize();
        void run();
        void directory();
        void quit();

        void Menu();

        GLFWwindow* getWindow(){return m_window;}

        void set_etape(string s){m_etapeActuelle = s;}
        string get_etape(){return m_etapeActuelle;}

        string getUserName(){return m_user.getUserName();}

        double getGravity(){return m_gravity;}
        void setGravity(double g){m_gravity = g;}
        int getBounceConst(){return m_bounceConst;}

        float getDeltaTime(){return m_deltaTime;}


        ///MATHS
        unsigned ten_exposant_n(unsigned n);
        double arrondi(const double x, unsigned n);
};

#endif // ENGINE_H
