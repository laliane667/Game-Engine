#include "world.h"

World *World::s_Instance = nullptr;

void World::initialize()
{
    Floor floor;
    m_floor = floor;

    /*Point p1(0, -2);
    Point p2(5, 3);
    Point p3(-5, 3);*/

    Point p1(-5, -2);
    Point p2(5, -2);
    Point p3(-3, 1);

    /*Point p1(-3, -3);
    Point p2(3, -3);
    Point p3(3, 3);
    Point p4(-3, 3);*/
    Object o1;

    o1.addPoint(p1);
    o1.addPoint(p2);
    o1.addPoint(p3);
    //o1.addPoint(p4);
    o1.initialize();
    m_objects.push_back(o1);
}

void World::displayWorld()
{
    for(unsigned long i = 0; i < m_objects.size(); i++)
        m_objects[i].display();
}

Vector2D World::getCollision(double x, double y)
{
    Vector2D R(0,0);

    for(unsigned long i = 0; i < m_objects.size(); i++)
    {
        R = m_objects[i].getCollision(x, y);
        if(R.getX()!= 0 && R.getY()!= 0)
            return R;
    }
    return R;
}

void Object::initialize()
{
    for(unsigned long i = 0; i < m_points.size(); i++)
    {
        double vx, vy;
        if(i == m_points.size()-1)
        {
            vx = m_points[0].getX() - m_points[i].getX();
            vy = m_points[0].getY() - m_points[i].getY();
        }
        else
        {
            vx = m_points[i+1].getX() - m_points[i].getX();
            vy = m_points[i+1].getY() - m_points[i].getY();
        }
        Vector2D vect(vx, vy);
        Vector2D norm(vy, -vx);
        m_vectors.push_back(vect);
        m_normalVectors.push_back(norm);
        m_collisionToSide.push_back(false);
        m_distToSide.push_back(0);
        cout << "|VectDir: " << i << "| X: " << m_vectors[i].getX() << " Y: " << m_vectors[i].getY();
        cout << "|Normal: " << i << "| X: " << m_normalVectors[i].getX() << " Y: " << m_normalVectors[i].getY() << endl;
    }
}

Vector2D Object::getCollision(double x, double y)
{
    int index = 0;
    double minValue = 10000;
    Vector2D R(0,0);
    Vector2D Rn;

    for(unsigned long i = 0; i < m_normalVectors.size(); i++)
    {
        m_collisionToSide[i] = false;
        double x1 = m_points[i].getX();
        double x2 = m_points[i].getY();
        double a = m_vectors[i].getY();
        double b = -m_vectors[i].getX();
        double c = -a*x1 - b*x2;
        double result = a*x+b*y+c;
        double dist = abs(result);
        m_distToSide[i] = dist;

        /*if(i == 2)
            cout << result << endl;*/

        if(result <= 0 && m_normalVectors[i].getX() > 0 && m_normalVectors[i].getY() > 0)
            m_collisionToSide[i] = true;
        if(result <= 0 && m_normalVectors[i].getX() < 0 && m_normalVectors[i].getY() > 0)
            m_collisionToSide[i] = true;
        if(result <= 0 && m_normalVectors[i].getX() < 0 && m_normalVectors[i].getY() < 0)
            m_collisionToSide[i] = true;
        if(result <= 0 && m_normalVectors[i].getX() > 0 && m_normalVectors[i].getY() < 0)
            m_collisionToSide[i] = true;
        if(result <= 0 && m_normalVectors[i].getX() == 0 && m_normalVectors[i].getY() < 0)
            m_collisionToSide[i] = true;
        if(result <= 0 && m_normalVectors[i].getX() == 0 && m_normalVectors[i].getY() > 0)
            m_collisionToSide[i] = true;
        if(x >= x1 && m_normalVectors[i].getX() < 0 && m_normalVectors[i].getY() == 0)
            m_collisionToSide[i] = true;
        if(x <= x1 && m_normalVectors[i].getX() > 0 && m_normalVectors[i].getY() == 0)
            m_collisionToSide[i] = true;

        /*if(result < 0 && m_normalVectors[i].getX() > 0 && m_normalVectors[i].getY() == 0)
            m_collisionToSide[i] = true;
        if(result > 0 && m_normalVectors[i].getX() < 0 && m_normalVectors[i].getY() == 0)
            m_collisionToSide[i] = true;*/
        //cout << "|Bool: " << i << " | " << m_collisionToSide[i] << endl;


    }
    for(unsigned long i = 0; i < m_normalVectors.size(); i++)
    {
        if(m_collisionToSide[i] == false)
        {
            //cout << i << endl;
            return R;
        }
        if(m_distToSide[i] < minValue)
        {
            minValue = m_distToSide[i];
            index = i;
        }

    }
    return m_normalVectors[index];
}


void Object::update()
{

}

void Object::display()
{
    for(unsigned long i = 0; i < m_points.size(); i++)
    {
        m_points[i].display();
    }

}

void Point::display()
{
    //circlefill(Engine::GetInstance()->get_bitmap("PAGE"),Engine::GetInstance()->getXCam(m_x), Engine::GetInstance()->getYCam(m_y),10, makecol(125,255,125));
}
