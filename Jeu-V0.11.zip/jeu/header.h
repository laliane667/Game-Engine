#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stb/stb_image.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <time.h>
#include <vector>
#include <map>
#include <iostream>
#include <cstdlib>
#include <cassert>
#include <cmath>
#include <math.h>
#include <fstream>
#include <sstream>


using namespace std;

void processInput(GLFWwindow *window);
void framebuffer_size_callback(GLFWwindow* window, int width, int height);

// settings
const unsigned int SCR_WIDTH = 1920;
const unsigned int SCR_HEIGHT = 1080;

class Vector2D
{
    public:
        Vector2D(){}
        Vector2D(double x, double y){m_x = x; m_y = y;}
        ~Vector2D(){}

        void setValue(double x, double y){m_x = x; m_y = y;}

        void setX(double x){m_x = x;}
        void setY(double y){m_y = y;}
        double getX(){return m_x;}
        double getY(){return m_y;}

    private:
        double m_x;
        double m_y;
};

#endif // HEADER_H_INCLUDED
